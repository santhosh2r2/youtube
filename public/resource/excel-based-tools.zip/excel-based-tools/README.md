# 📁 Excel-Based Automation Tools – Resource Files

This repository contains all the **resource files** used in the [YouTube video](https://www.youtube.com/watch?v=cHXuMWTlaqk&ab_channel=SanthoshBalajiRamesh) titled:

**🔧 “In-depth Excel Tools Showcase: Automate, Monitor & More!”**  
by [Santhosh Balaji Ramesh](https://www.youtube.com/@santhoshbalajiramesh)

Whether you're automating network tasks, generating reports, or integrating with macOS, this folder has all the tools showcased—ready for hands-on use.

---

## 📦 Folder Contents

| Sl. No | File Name | Description |
|--------|-----------|-------------|
| 01 | `01_Part 1 - Simple Tester.xlsm` | Basic ping tool to test network connectivity. |
| 02 | `02_03_Part 2_3 - Monitor_and_Scheduler.xlsm` | Advanced monitoring and scheduling using Excel. |
| 03 | `03_Scheduler.vbs.txt` → Rename to `Scheduler.vbs` | VBScript to automate the Scheduler. Used for background execution. |
| 04 | `04_Export as PDF.xlsm` | Automatically export reports or results as PDF from Excel. |
| 05 | `05_Part 1 - Send Email.xlsm` | Send emails directly from Excel. |
| 06 | `06_Visualization Using Charts.xlsm` | Data visualization with interactive Excel charts. |
| 07 | `07_MACOS_Integration.xlsm` | macOS-specific integrations using AppleScript. |
| 08 | `07_MACOS_Integration.applescript.txt` → Rename to `MACOS_Integration.applescript` | AppleScript source file. Place alongside the Excel file. |
| 09 | `08_MACOS Find Hostname & Open Ports.xlsm` | Discover hostnames and open ports on macOS. |
|    | `08_MACOS Find Hostname & Open Ports.host.applescript` | AppleScript for hostname discovery. |
|    | `08_MACOS Find Hostname & Open Ports.port.applescript` | AppleScript for open port detection. |
| 10 | `09_Ping in PHP.php` | A PHP version of the ping tool. |
| 11 | `10_Ping in NodeJS.js` | Node.js version of the ping tool. |
| 12 | `11_Find MAC Address.xlsm` | Get the MAC address of a device from Excel. |
| 13 | `12_ Lookup Hostname from IP Address.xlsm` | Resolve hostnames from IPs. |
| 14 | `13 _ Lookup IP Address from Hostname.xlsm` | Resolve IPs from hostnames. |
| 15 | `14_Import_Outlook_Emails.xlsm` | Extract emails from Outlook directly into Excel. |
| 16 | `15_send_whatsapp_message.xlsm` | Send WhatsApp messages using Excel. |
| 17 | `16_Test_SSH_Login.xlsm` | Verify SSH login access from Excel. |
| — | `README.txt` → You are reading it! |

---

## 📝 Notes

- Files with `.vbs.txt` or `.applescript.txt` **must be renamed**:
  - Example: Rename `03_Scheduler.vbs.txt` to `Scheduler.vbs`
- AppleScript files should be used with **macOS Script Editor**.
- All `.xlsm` files are **macro-enabled Excel workbooks**, so make sure to **enable macros** upon opening.
- Designed and tested on **Windows**. macOS features require additional AppleScript steps as shown in the video.

---

## 📺 Watch the Full Video

📹 [Watch here on YouTube](https://www.youtube.com/watch?v=cHXuMWTlaqk&ab_channel=SanthoshBalajiRamesh)

### ⏱️ Timestamps Covered

- **Ping Tool**  
  - 00:00:00 – Simple Tester  
  - 00:06:59 – Monitor  
  - 00:18:48 – Scheduler  
  - 00:25:00 – Export as PDF  
  - 00:31:29 – Send Email  
  - 00:46:35 – Gmail Settings Update  

- **Advanced Features**  
  - 00:50:41 – Visualization with Charts  
  - 01:01:24 – macOS Integration  
  - 01:08:37 – Find Hostname & Open Ports on macOS  

- **Other Languages**  
  - 01:15:53 – PHP Version  
  - 01:17:56 – NodeJS Version  

- **Miscellaneous Tools**  
  - 01:21:26 – Find MAC Address  
  - 01:24:44 – Hostname Lookup  
  - 01:28:54 – IP Lookup  
  - 01:31:14 – Outlook Email Import  
  - 01:44:31 – WhatsApp Messaging  
  - 01:51:09 – SSH Login Tester  

---

## 💬 Support

If you have questions or issues, drop a comment under the video or connect via the YouTube channel:  
👉 [@santhoshbalajiramesh](https://www.youtube.com/@santhoshbalajiramesh)

---

## 🔐 Disclaimer

These tools are provided **as-is** for learning and automation. Please review all scripts and code before deploying in production environments.

---

## 👍 Like • 🔁 Share • 🔔 Subscribe

Stay tuned for more Excel-based utilities, automation tips, and network tools!